public class PTMusang {
	private String KodeKaryawan="";
	private String NamaKaryawan="";
	private String JenisKelamin="";
	private String Jabatan="";
	private Integer GajiKaryawan=0;
	
	public String getKodeKaryawan() {
		return KodeKaryawan;
	}
	public void setKodeKaryawan(String kodeKaryawan) {
		KodeKaryawan = kodeKaryawan;
	}
	public String getNamaKaryawan() {
		return NamaKaryawan;
	}
	public void setNamaKaryawan(String namaKaryawan) {
		NamaKaryawan = namaKaryawan;
	}
	public String getJenisKelamin() {
		return JenisKelamin;
	}
	public void setJenisKelamin(String jenisKelamin) {
		JenisKelamin = jenisKelamin;
	}
	public String getJabatan() {
		return Jabatan;
	}
	public void setJabatan(String jabatan) {
		Jabatan = jabatan;
	}
	public Integer getGajiKaryawan() {
		return GajiKaryawan;
	}
	public void setGajiKaryawan(Integer gajiKaryawan) {
		GajiKaryawan = gajiKaryawan;
	}

}
